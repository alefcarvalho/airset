//------------------------------------------
// NAVIGATION
//------------------------------------------
var pppCheckCnt = 0;
var pppStatus = 0;
var dslStatus = 0;
var securitypassWEP = "";
var securitypassWPA = "";

function navPage( page )
{
	
	var addr = null;
	
	
	// DEFINE PAGE	
	switch( page )
	{
		
		// PAGES
		case "home":
	  		navPageLink( "index-2.html" );
	  		break;
	  		
	  	case "welcome_l":
	  		navPageLink( "oi_wizardf4af.html?viewPage=bem_vindo&amp;userType=house" );
	  		break;

	  	case "welcome_r":
	  		navPageLink( "oi_wizard5e5a.html?viewPage=bem_vindo&amp;userType=company" );
	  		break;
	  		
	  	case "detecting":
	  		navPageLink( "detectando.html" );
	  		break;
	  		
		case "set_modem_residential":
	  		navPageLink( "oi_wizard8428.html?viewPage=wanCfgView&amp;userType=house" );
			pppCheckCnt = 0;
			pppStatus = 0;
	  		break;
        
		case "back_l":
	  		navPageLink( "oi_wizardf217.html?viewPage=wanCfgView&amp;userType=house&amp;isSubmit=2" );
			pppCheckCnt = 0;
			pppStatus = 0;
	  		break;
	  		
		case "set_modem_commercial":
	  		navPageLink( "oi_wizard74c9.html?viewPage=wanCfgView&amp;userType=company" );
			pppCheckCnt = 0;
			pppStatus = 0;
	  		break;

		case "back_r":
			navPageLink( "oi_wizard2477.html?viewPage=wanCfgView&amp;userType=company&amp;isSubmit=2" );
			pppCheckCnt = 0;
			pppStatus = 0;
	  		break;
	  			
	  	case "host":
			pppCheckCnt = 0;
			pppStatus = 0;
			
			getWizardPPPoE();

			if (pppStatus == 1)
			{
		  		//navPageLink( "provedor.html" );
		  		//navPageLink( "http://www.google.com" );
		  		navPageLink( "http://www.urlprovedores.com.br/" );
			}
			else
			{
		  		navPageLink( "falha_autenticacao_padrao.html" );
			}
	  		break;
        
		case "host2":
			window.location.href = "http://primeiroacesso.oi.com.br/";
			// navPageLink( "http://primeiroacesso.oi.com.br" );
			break;
        
		case "falha_autenticacao_padrao":
			window.location.href = "falha_autenticacao_padrao.html";
			break;
	  		
		case "authentication_failure":
	  		// navPageLink( "/wizardoi/oi_wizard.cgi?viewPage=falha_autenticacao" );
	  		navPageLink( "falha_autenticacao.html" );
	  		break;
	  			
		case "authentication_failure_velox":
	  		navPageLink( "falha_autenticacao_velox.html" );
	  		break;
	  		
		case "authentication_failure_velox_video":
        navPageLink( "falha_autenticacao_velox_video.html" );
	  		break;
        
		case "tryDSL":
	  		navPageLink( "oi_wizard46ba.html?viewPage=verificando" );
	  		break;

		case "falha_conexao_velox_video":
	  		navPageLink( "oi_wizard5c61.html?viewPage=falha_conexao_velox_video" );
	  		break;
        
		case "falha_conexao_velox_video_redirect":
	  		navPageLink( "oi_wizard4915.html?viewPage=falha_conexao_velox_video&amp;isRedirect=1" );
	  		break;
	  		
		case "interface_failure":
	  		navPageLink( "falha_interface.html" );
	  		break;
	  			
		case "troubleshooting":
	  		navPageLink( "solucionando_problemas.html" );
	  		break;
	  			
		case "modem_off_problem":
	  		navPageLink( "problema_modem_apagado.html" );
	  		break;
	  			
		case "adsl_off_problem":
	  		navPageLink( "problema_adsl_apagada.html" );
	  		break;
	  			
		case "ethernet_shield_problem":
	  		navPageLink( "problema_placa_de_rede.html" );
	  		break;
	  			
		case "user_password_problem":
	  		navPageLink( "problema_usuario_senha.html" );
	  		break;
	  			
		case "connectionless_problem":
	  		navPageLink( "problema_sem_conexao.html" );
	  		break;
	  		
		case "no_navigation_problem":
	  		navPageLink( "problema_sem_navegacao.html" );
	  		break;
	  			
		case "slow_browsing_problem":
	  		navPageLink( "problema_navegacao_lenta.html" );
	  		break;
	  		
	  	case "configure_wifi":
	  		navPageLink( "oi_wizard9bdc.html?viewPage=wifiCfgView" );
	  		break;

		case "fon_service":
	  		// navPageLink( "/wizardoi/oi_wizard.cgi?viewPage=fonCfgView" );
	  		window.top.location = "http://192.168.1.1/fon/";
	  		break;
	  		
		case "setting":
	  		navPageLink( "configurando.html" );
	  		break;
	  		
		case "configured":
	  		navPageLink( "configurado.html" );
	  		break;
	  		
		case "blank":
	  		navPageLink( "em_branco.html" );
	  		break;
	  		
		case "rede_fon":
	  		// navPageLink( "rede_fon.html" );
	  		window.top.location = "http://192.168.1.1/fon/";
	  		break;
	  		
		case "registered_residential":
	  		navPageLink( "cadastrado_residencial.html" );
	  		break;
	  		
		case "registered_commercial":
	  		navPageLink( "cadastrado_comercial.html" );
	  		break;
	  		
		case "modem_installed":
	  		// navPageLink( "modem_instalado.html" );
	  		navPageLink( "oi_wizard083d.html?viewPage=modem_instalado" );
	  		break;
        
		case "redireciona_portal":
			navPageLink_blank( "redireciona_portal.html" );
			break;
	  		
			
			
		// BTN ACTION
		case "close":
	  		window.parent.close();
	  		break;
	  		
		case "retry":
	  		navPageLink( "oi_entry.html" );
	  		break;
	  			
		case "browsing_residential":
	  		// navPageLink( "http://www.oi.com.br/boasvindas_oipravoce" );
	  		window.top.location = "http://www.oi.com.br/boasvindas_oipravoce";
	  		break;

		case "browsing_commercial":
	  		// navPageLink( "http://www.oi.com.br/boasvindas_oipranegocios" );
	  		window.top.location = "http://www.oi.com.br/boasvindas_oipranegocios";
	  		break;

		case "back":
			navPageLink( "solucionando_problemas.html" );
	  		break;

		// LINKS	
		case "video":
	  		//navPageLink( "http://" );
			navPageLink( "Video/OiVeloxADSLHelp.html" );
	  		break;
	  		
		case "contract":
	  		navPageLink( "http://fon-instalacao.oi.com.br/contrato/contrato_de_adesao.html" );
	  		break;
	  			
		case "site":
	  		navPageLink( "http://www.oi.com.br/" );
	  		break;

		case "configurando_WAN":
	  		navPageLink( "oi_wizard7689.html?viewPage=configurandoWAN" );
	  		break;			  				
	  		
	}
}

function navPageLink( addr )
{
	// WINDOW TARGET
	var wTarget = "_self";
	var randomStr = 'v='+Math.random();
	if( addr.indexOf( "http://" ) > -1 ) wTarget = "_blank";


	//prevent cache	
	if( addr.indexOf( ".cgi?" ) > -1 )
		addr += "&"+randomStr;
	else if ( addr.indexOf( ".cgi" ) > -1 )
		addr += "?"+randomStr;
	
	// NAV
	if( addr ) window.open( addr, wTarget );
}

function navPageLink_blank( addr )
{
	// WINDOW TARGET
	var wTarget = "_blank";
	var randomStr = 'v='+Math.random();
	if( addr.indexOf( "http://" ) > -1 ) wTarget = "_blank";


	//prevent cache	
	if( addr.indexOf( ".cgi?" ) > -1 )
		addr += "&"+randomStr;
	else if ( addr.indexOf( ".cgi" ) > -1 )
		addr += "?"+randomStr;
	
	// NAV
	if( addr ) window.open( addr, wTarget );

}

function setWizardPPPoE(postData, nextPage){
	$.ajax({
	    url: "/wizardoi/oi_wizard.cgi",
		type:'POST',
		data: postData,
		cache: false,
	  	success: function(returnData){
			checkPPPoE(nextPage);
		},
		error: function() {
			alert("Configure PPPoE connection fail");
			navPage( 'authentication_failure' );
		}
	});
}

function checkPPPoE(nextPage)
{
	if (pppStatus == 1)
	{
//		alert("PPPoE connection is up, move to WIFI page.");
	}
	else if (pppStatus != 1 && pppCheckCnt < 2)
	{
//		alert("PPPoE connection is not up, try again("+pppCheckCnt+").");
//		setTimeout("checkPPPoE()", 5000);
	}
	else
	{
//		alert("PPPoE connection is not up, give up("+pppCheckCnt+").");
	}
	navPage( nextPage );
}

function getWizardPPPoE(){
	$.ajax({
	  	url: '/wizardoi/oi_getInfo.cgi?viewPage=wzPPPoE',
	  	dataType: 'text',
		type:'GET',
		async: false,
		cache: false,
	  	success: function(text){
      var temp = text.split(" ");
      dslStatus = temp[0];
			pppStatus = temp[1];
			pppCheckCnt++;
		},
		error: function() {

		}
	});
}

function getWizardPPPoENoUpdate(){
	$.ajax({
	  	url: '/wizardoi/oi_getInfo.cgi?viewPage=wzPPPoE&noUpdate=1',
	  	dataType: 'text',
		type:'GET',
		async: false,
		cache: false,
	  	success: function(text){
      var temp = text.split(" ");
      dslStatus = temp[0];
			pppStatus = temp[1];
			pppCheckCnt++;
		},
		error: function() {

		}
	});
}

/*
function getWizardPPPoE(){
	$.ajax({
	  	url: '/wizardoi/oi_getInfo.cgi?viewPage=wzPPPoE',
	  	dataType: 'json',
		type:'GET',
		async: false,
		cache: false,
	  	success: function(returnData){
			pppStatus = returnData.WIZARD.PPP.pppStatus;
      			dslStatus = returnData.WIZARD.physicalStatus;
			pppCheckCnt++;
		},
		error: function() {

		}
	});
} 

function getWizardPPPoENoUpdate(){
	$.ajax({
	  	url: '/wizardoi/oi_getInfo.cgi?viewPage=wzPPPoE&noUpdate=1',
	  	dataType: 'json',
		type:'GET',
		async: false,
		cache: false,
	  	success: function(returnData){
			pppStatus = returnData.WIZARD.PPP.pppStatus;
      			dslStatus = returnData.WIZARD.physicalStatus;
			pppCheckCnt++;
		},
		error: function() {

		}
	});
} */

function getWizardWIFI(){
	$.ajax({
	  	url: '/wizardoi/oi_getInfo.cgi?viewPage=wzWifi',
	  	dataType: 'json',
		type:'GET',
		cache: false,
	  	success: function(returnData){
			securitypassWEP = returnData.WIFI.SECURITY.passwordWEP;
			securitypassWPA = returnData.WIFI.SECURITY.passwordWPA;
		},
		error: function() {

		}
	});
}

