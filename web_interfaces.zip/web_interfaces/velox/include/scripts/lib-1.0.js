//-------------------------------------------------------------------------
// lib-1.0.js -- The basic js lib for data checking
// ------------------------------------------------------------------------
// 2010-12-26 | Creation | Rain
//-------------------------------------------------------------------------


//------------------------------------------------------------
// Basic Characters Test Functions
//------------------------------------------------------------
function isDigit( value )
{
	var re = /^[0-9]*$/;
	return re.test(value);
}

function isXdigit( value )
{
	var re = /^[0-9a-fA-F]*$/;
	return re.test(value);
}

function isLower( value )
{
	var re = /^[a-z]*$/;
	return re.test(value);
}

function isUpper( value )
{
	var re = /^[A-Z]*$/;
	return re.test(value);
}

function isAscii( value )
{
	// visiable characters([32,33],[35-126]) exclue '"'
	var re = /^[\040-\041\043-\176]*$/;
	return re.test(value);
}

function isAlpha( value )
{
	var re = /^[a-zA-Z]*$/;
	return re.test(value);
}

function isAlnum( value )
{
	var re = /^[0-9a-zA-Z]*$/;
	return re.test(value);
}

function isNumber()
{
	var e = window.event;

	if (e.keyCode)
	{
		key = e.keyCode;
	}
	else if (e.which)
	{
		key = e.which;
	}

	if (key < 48 || key > 57)
	{
		event.returnValue = false;
	}
}
//------------------------------------------------------------
// Extensiable Test Functions
//------------------------------------------------------------
function isValidSSID( ssid )
{
	var re = /^[0-9a-zA-Z_-]*$/;
	return re.test(ssid);
}

function isValidPasswd( passwd )
{
	var re = /^[0-9a-zA-Z_-]*$/;
	return re.test(passwd);
}

function isValidHex( hexString )
{
	var re = /^[0-9a-fA-F]*$/;
	return re.test(hexString);
}

function isValidIPv4Byte1( value )
{
	var re = /^([1-9][0-9]?)|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5])$/;
	return re.test(value);
}

function isValidIPv4Byte2( value )
{
	var re = /^(0)|([1-9][0-9]?)|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5])$/;
	return re.test(value);
}

function isValidMailAddress( value )
{
	var re = /^[a-zA-Z0-0_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*$/;
	return re.test(value);
}

function checkIp( ip )
{
	var ipPattern = new RegExp("^(([1-9][0-9]?)|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\\.((0)|([1-9][0-9]?)|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\\.((0)|([1-9][0-9]?)|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\\.((0)|([1-9][0-9]?)|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))$", "g");
	var ip6Pattern = new RegExp("^(^::$)|(^([\\d|a-fA-F]{1,4}:){7}([\\d|a-fA-F]{1,4})$) |(^(::(([\\d|a-fA-F]{1,4}):){0,5}([\\d|a-fA-F]{1,4}))$) |(^(([\\d|a-fA-F]{1,4})(:|::)){0,6}([\\d|a-fA-F]{1,4})$)$", "g");

	if (ipPattern.test(ip))
	{
		return true;
	}

	if (ip6Pattern.test(ip))
	{
		var pos=ip.indexOf("::");
		if (pos>-1)
		{
			pos=ip.indexOf("::",pos+2);
			if (pos>-1) return false;
		}
		return true;
	}
	return false;
}

function checkMac( mac )
{
	var re = /^[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]:[0-9A-Fa-f][0-9A-Fa-f]$/;
	return re.test(mac);
}

function isValueInRange(value, min, max)
{
	if (value < min || value > max)
	{
		return false;
	}
	else
	{
		return true;
	}
}

function setCursor(field)
{
	if (field.createTextRange)
	{
		var r = field.createTextRange();
		r.collapse();
		r.moveStart('character', 0);
		r.moveEnd('character', field.value.length);
		r.select();
	}
}

var fieldLen;
function setFieldLen(curField)
{
	fieldLen = curField.value.length;
}

function ipFiledEvent(curField, preObj, nextObj, func, min, max, check127)
{
	var e = window.event;

	if (e.keyCode)
	{
		key = e.keyCode;
	}
	else if (e.which)
	{
		key = e.which;
	}

	switch (key)
	{
		case 8: // Backspace
			{
				if (fieldLen == 0 && preObj != undefined)
				{
					curField.blur();
					preObj.focus();
					setCursor(preObj);
				}

				return true;
			}
		case 110: // Dot
		case 190: // Dot
			{
				curField.value = curField.value.replace(/[^0-9]/g,"");
				if (nextObj != undefined)
				{
					if (curField.value.length == 0)
					{
						return true;
					}

					if (func(curField, min, max, check127))
					{
						curField.blur();
						nextObj.focus();
						setCursor(nextObj);
					}
					else
					{
						return false;
					}
				}

				return true;
			}
		default:
			return func(curField, min, max, check127);
	}
}

/* convert query string into json */
$.par2Json = function(string, overwrite) {
		var obj = {},
		pairs = string.split('&'),
		d = decodeURIComponent,
		name,
		value;
	$.each(pairs, function(i,pair) {
		pair = pair.split('=');
		name = d(pair[0]);
		value = d(pair[1])+'='+d(pair[2]);
		obj[name] = overwrite || !obj[name] ? value : [].concat(obj[name]).concat(value);
	});
	return obj;
};

function close_window()
{
	var browserName=navigator.appName; 
	if (browserName=="Netscape")
	{ 
		function closeme() 
		{ 
			window.open('','_parent',''); 
			window.parent.top.close();
		} 
		closeme();
	} 
	else 
	{ 
		if (browserName=="Microsoft Internet Explorer") 
		{ 
			function closynoshowsme() 
			{ 
				window.opener = "whocares"; 
				window.parent.close();
			} 
			closynoshowsme();
		} 
	} 
}
